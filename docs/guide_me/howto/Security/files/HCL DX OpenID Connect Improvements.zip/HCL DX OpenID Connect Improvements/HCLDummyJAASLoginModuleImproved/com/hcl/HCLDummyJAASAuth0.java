/*
 ********************************************************************
 * Licensed Materials - Property of HCL                             *
 *                                                                  *
 * Copyright HCL Technologies Ltd. 2001, 2020. All Rights Reserved. *
 *                                                                  *
 * Note to US Government Users Restricted Rights:                   *
 *                                                                  *
 * Use, duplication or disclosure restricted by GSA ADP Schedule    *
 ********************************************************************
 */
package com.hcl;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import com.ibm.portal.auth.tai.ExternalIdentityCredential;
import com.ibm.websphere.security.UserRegistry;
import com.ibm.wsspi.security.auth.callback.WSTokenHolderCallback;
import com.ibm.wsspi.security.token.AttributeNameConstants;

import java.util.ArrayList;

// The following imports enable attribute and group functionality for transient users.
import com.ibm.websphere.security.oidc.util.OidcClientHelper;

import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.io.IOException;
import java.net.URLEncoder;


import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MultivaluedHashMap;




/*
 * HCLDummyJAASAuth0
 * This class builds the Subject for OIDC-authenticated Auth0 users such that Transient Users function properly,
 * including mapping attributes and resolving group membership.
 * 
 * Modify this code for other OPs, since tokens, attributes, and REST APIs will differ.
 * 
 * THE SECURITY OF THIS LOGIN MODULE HAS NOT BEEN VERIFIED BY ANY THIRD PARTY.
 * THIS IS FOR PROOF-OF-CONCEPT AND TESTING PURPOSES ONLY.
 * 
 */

public class HCLDummyJAASAuth0 implements LoginModule {

	private static final String DISCLAIMER="HCLDummyJAASAuth0 - WARNING - DO NOT USE IN PRODUCTION - NOT VALIDATED AS SECURE BY ANY THIRD PARTY";
	
    private boolean success = false;
    Subject currentSubject;
    CallbackHandler currentCallbackHandler;
    Map<String, Object> currentSharedState;
    Map<String, Object> currentOptions;
    
	private static final String HTTPS = "https://";
	
	// At the time of this comment, the OidcClientHelper utility class does not provide access to these values.
    // This sample code assumes a file exists at the location specified in the login module custom property, opInfoPath. 
	// This JSON file must have exactly one line of content structured like:
	// {"tenant"="replace with your tenant FQHN":"client_id":"replace with your client ID","client_secret":"replace with your client secret"}
	// FQHN - fully qualified host name
	// 
	private static JSONObject OP_JSON;
	private static String CLIENT_ID;
	private static String CLIENT_SECRET;
	private static String TENANT_FQHN;
	private static String TENANT;
	
    @Override
    public void initialize(Subject subject, CallbackHandler callbackHandler,
            Map<String, ?> sharedState, Map<String, ?> options) {
    	System.out.println(DISCLAIMER);
    	System.out.println("HCLDummyJAASAuth0.initialize()");
        currentSubject = subject;
        currentCallbackHandler = callbackHandler;
        currentSharedState = (Map<String, Object>) sharedState;
        currentOptions = (Map<String, Object>) options;
        success = false;
        
        try {
        	String opInfoPath = (String) options.get("opInfoPath");
        	// This assumes the JSON is all on one line.
			OP_JSON = (JSONObject) JSON.parse(Files.readAllLines(FileSystems.getDefault().getPath(opInfoPath),StandardCharsets.US_ASCII).get(0));
			CLIENT_ID = (String) OP_JSON.get("client_id");
			CLIENT_SECRET = (String) OP_JSON.get("client_secret");
			TENANT_FQHN = (String) OP_JSON.get("tenant_fqhn");
			TENANT = HTTPS + TENANT_FQHN;
		} catch (NullPointerException | IOException e) {
			// Prefer null check to catching NPE, but leaving this in sample code for simplicity.
			System.out.println("HCLDummyJAASAuth0.initialize() - FAILURE READING CONFIGURATION");
			e.printStackTrace();
		}
        
    }
    
    // Resolve group membership for Auth0 users:
    // Query Auth0 Management API for user roles and map these to existing user groups in DX.
    // DX groups can be created by administrators or automatically provisioned via PUMA.
    // This sample uses the file repository, though Application Groups would be more suitable for production.
    // Some OPs provide groupIds in the IDToken, which would enable OidcClientHelper usage rather than querying an API.
    private void resolveAuth0Groups(String userSub, Hashtable hashtable) throws IOException {

    	// Auth0 & Client Credentials Flow
    	// Client Credentials Flow: https://tools.ietf.org/html/rfc6749#section-4.4
    	
    	// Step 1: An HTTP POST to obtain the access token.
    	// OidcClientHelper.getClientCredentialsGrantAccessToken() could be an alternative for compatible OPs.
    	
    	// Method scope used here for clarity in sample code.
    	// Best practice would be to use static fields.
    	javax.ws.rs.client.Client client = ClientBuilder.newClient();
    	WebTarget tenant = client.target(TENANT);
    	WebTarget tokenEP = tenant.path("oauth/token");
    	
    	MultivaluedHashMap<String,String> tokenFormData = new MultivaluedHashMap<String, String>();
    	tokenFormData.add("grant_type", "client_credentials");
    	tokenFormData.add("client_id", CLIENT_ID);
    	tokenFormData.add("client_secret", CLIENT_SECRET);
    	tokenFormData.add("audience", TENANT + "/api/v2/");
    	
    	String tokenResponseString = tokenEP.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).post(Entity.form(tokenFormData),String.class);

    	// Step 2: OP verifies the client_id and client_secret.
    	
    	// Step 3: Read the access token from the JSON response.
    	// com.ibm.json.java.* chosen for ease of integration with IBM WebSphere Application Server
    	// JSON library of choice may be substituted.
    	JSONObject tokenResponseJSON = (JSONObject) JSON.parse(tokenResponseString);
    	String accessToken = (String) tokenResponseJSON.get("access_token");

    	// Step 4: Request role data from Auth0
    	// Use management API: https://auth0.com/docs/api/management/v2#!/Users/get_user_roles
    	String userSubURL = URLEncoder.encode(userSub, "UTF-8");
    	WebTarget rolesEP = tenant.path("api/v2/users/" + userSubURL + "/roles");
    	String rolesResponseString = rolesEP.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).header("Authorization", "Bearer " + accessToken).get(String.class);
    	
    	// Step 5: Parse the response
    	JSONArray rolesResponseJSONArray = (JSONArray) JSON.parse(rolesResponseString);

    	// Put the group list in the subject.
    	// Configure group reuse so that DX pulls users' group membership from the subject.
    	ArrayList<String> groupList = new ArrayList<String>();
    	Iterator<JSONObject> it = rolesResponseJSONArray.iterator();
    	while (it.hasNext()) {
    		JSONObject roleXJSON = (JSONObject) it.next();
    		String roleX = (String) roleXJSON.get("name");
    		groupList.add("cn=" + roleX +",o=defaultWIMFileBasedRealm");
    		// A group with this DN must exist in the user repository in order to assign DX roles.
    		// If no such group exists, this inclusion in WSCREDENTIAL_GROUPS is inconsequential to DX.
    		// A verification, mapping, or provisioning procedure could be added in this block.
    	}
    	hashtable.put(AttributeNameConstants.WSCREDENTIAL_GROUPS,groupList);
    }
    
    @Override
    public boolean login() throws LoginException {
    	System.out.println(DISCLAIMER);
    	System.out.println("HCLDummyJAASAuth0.login()");
    	
        String uniqueid = "";

        Hashtable hashtable = new Hashtable();
        Callback callbacks[] = new Callback[2];
        try {
            callbacks[0] = new WSTokenHolderCallback("");
            callbacks[1] = new NameCallback("User:");
            currentCallbackHandler.handle(callbacks);

            boolean requiresLogin = ((WSTokenHolderCallback) callbacks[0]).getRequiresLogin();

            if (requiresLogin) {
                String username = ((NameCallback) callbacks[1]).getName();
                if (username != null) {
                    try {
                    	// *** CAUTION ***
                    	// This is designed to associate the transient user with a provisioned user, if one exists.
                    	// However, for any environment using both OIDC and a traditional user registry,
                    	// this could be a security vulnerability if the username exists in both the OP and the DX registry.
                    	//
                        // try to find valid user for given username/eMail
                        InitialContext ctx = new InitialContext();
                        UserRegistry reg = (UserRegistry) ctx.lookup("UserRegistry");
                        uniqueid = reg.getUniqueUserId(username);
                    } catch (com.ibm.websphere.security.EntryNotFoundException e1) {
                        // Entry was not found - or not unique in defaultRealm
                    	// This is not designed for VP / Realms.
                        System.out.println("HCLDummyJAASAuth0 - transient user");
                        
                        // OidcClientHelper: https://www.ibm.com/support/knowledgecenter/SSAW57_9.0.5/com.ibm.websphere.javadoc.doc/web/apidocs/com/ibm/websphere/security/oidc/util/OidcClientHelper.html
                        // Pass in the subject since this is a JAAS login module. 
                        String userInfoString = OidcClientHelper.getUserInfoFromSubject(currentSubject);
                        
                    	// com.ibm.json.java.* chosen for ease of integration with IBM WebSphere Application Server
                    	// JSON library of choice may be substituted.
                        JSONObject userInfoJSON = (JSONObject) JSON.parse(userInfoString);
                        System.out.println("HCLDummyJAASAuth0 - JSONObject userInfoJSON = " + userInfoJSON);
                        
                        username = (String) userInfoJSON.get("nickname");
                        uniqueid = "uid=" + username + ",o=transparent";
                        hashtable.put(AttributeNameConstants.WSCREDENTIAL_UNIQUEID,uniqueid);
                        hashtable.put(AttributeNameConstants.WSCREDENTIAL_SECURITYNAME,uniqueid);
                       
                       // Auth0 stores the email address in the "name" property.
                       String emailFromJSON = (String) userInfoJSON.get("name");

                       // The "sub" property is used in the Auth0 Management API.
                       String userSubFromJSON = (String) userInfoJSON.get("sub");
                       
                       // Resolve group membership for Auth0 users.
                       resolveAuth0Groups(userSubFromJSON, hashtable);
                        
                        // Add attributes for this user.
                        // Native WAS security code could access these from the public credentials.
                        // See ExternalIdentityCredential comments, below.
                        hashtable.put("sn",username);
                        hashtable.put("cn",username);
                        hashtable.put("uid",username);
                        hashtable.put("givenName", userSubFromJSON);
                        hashtable.put("ibm-primaryEmail",emailFromJSON);
                        
                        currentSubject.getPublicCredentials().add(hashtable);
                        
                        System.out.println("HCLDummyJAASAuth0 - OidcClientHelper.getUserInfoFromSubject(currentSubject): " + OidcClientHelper.getUserInfoFromSubject(currentSubject));
                        System.out.println("HCLDummyJAASAuth0 - OidcClientHelper.getIdTokenFromSubject(currentSubject): " + OidcClientHelper.getIdTokenFromSubject(currentSubject));
                        
                        // ExternalIdentityCredential facilitates TransparentUserFilter.
                        // Javadoc pending publication.
                        currentSubject.getPublicCredentials().add(new ExternalIdentityCredential(hashtable));
                        
                        currentSharedState.put(AttributeNameConstants.WSCREDENTIAL_PROPERTIES_KEY,hashtable);

                    } catch (Exception e1) {
                        System.out.println("HCLDummyJAASAuth0 failed: "+ e1);
                    }
                    System.out.println("HCLDummyJAASAuth0 uniqueid = " + uniqueid);
                } else {
                	
                    System.out.println("HCLDummyJAASAuth0 uniqueid is null - do nothing");
                    success = false;
                    System.out.println("HCLDummyJAASAuth0 failed with uniqueid= " + uniqueid);
                    return success;
                }
            } else {
                System.out.println("HCLDummyJAASAuth0 - This is a repeat login, nothing to do.");
            }

        } catch (Exception e) {
            System.out.println("HCLDummyJAASAuth0 failed: " + e);
        }
        success = true;
        System.out.println("HCLDummyJAASAuth0 succeeded with uniqueid = " + uniqueid);
        return success;
    }

    @Override
    public boolean commit() throws LoginException {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean abort() throws LoginException {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean logout() throws LoginException {
        // TODO Auto-generated method stub
        return false;
    }

}
