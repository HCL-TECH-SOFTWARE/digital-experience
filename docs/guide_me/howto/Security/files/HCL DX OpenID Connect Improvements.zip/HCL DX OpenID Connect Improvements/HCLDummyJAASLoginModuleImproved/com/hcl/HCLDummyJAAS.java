/*
 ********************************************************************
 * Licensed Materials - Property of HCL                             *
 *                                                                  *
 * Copyright HCL Technologies Ltd. 2001, 2020. All Rights Reserved. *
 *                                                                  *
 * Note to US Government Users Restricted Rights:                   *
 *                                                                  *
 * Use, duplication or disclosure restricted by GSA ADP Schedule    *
 ********************************************************************
 */
package com.hcl;

import java.util.Hashtable;
import java.util.Map;
import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import com.ibm.portal.auth.tai.ExternalIdentityCredential;
import com.ibm.websphere.security.UserRegistry;
import com.ibm.wsspi.security.auth.callback.WSTokenHolderCallback;
import com.ibm.wsspi.security.token.AttributeNameConstants;

// Not used functionally in this class
import com.ibm.websphere.security.oidc.util.OidcClientHelper;

/*
 * HCLDummyJAAS works in conjunction with HCLDummyTAI
 * This class builds the Subject such that Transient Users function properly
 * 
 * THIS IS NOT A SECURE IMPLEMENTATION OF A JAAS LOGIN MODULE.
 * THIS IS FOR PROOF-OF-CONCEPT AND TESTING PURPOSES ONLY.
 * 
 */

public class HCLDummyJAAS implements LoginModule {

	private static final String DISCLAIMER="HCLDummyJAAS - FOR TESTING ONLY - NOT SECURE";
    private boolean success = false;
    Subject currentSubject;
    CallbackHandler currentCallbackHandler;
    Map<String, Object> currentSharedState;
    Map<String, Object> currentOptions;

    @Override
    public void initialize(Subject subject, CallbackHandler callbackHandler,
            Map<String, ?> sharedState, Map<String, ?> options) {
    	System.out.println(DISCLAIMER);
    	System.out.println("HCLDummyJAAS.initialize()");
        currentSubject = subject;
        currentCallbackHandler = callbackHandler;
        currentSharedState = (Map<String, Object>) sharedState;
        currentOptions = (Map<String, Object>) options;
        success = false;
    }

   
    @Override
    public boolean login() throws LoginException {
    	System.out.println(DISCLAIMER);
    	System.out.println("HCLDummyJAAS.login()");
    	
    	// This logic is like that used in the SAML proof-of-concept,
    	// previously published for DX customer reference.
    	
        String uniqueid = "";

        Hashtable hashtable = new Hashtable();
        Callback callbacks[] = new Callback[3];
        try {
            callbacks[0] = new WSTokenHolderCallback("");
            callbacks[1] = new NameCallback("User:");
            callbacks[2] = new PasswordCallback("Password:", false); // not used
            currentCallbackHandler.handle(callbacks);

            boolean requiresLogin = ((WSTokenHolderCallback) callbacks[0]).getRequiresLogin();

            if (requiresLogin) {
                String username = ((NameCallback) callbacks[1]).getName();
                System.out.println("username = " + username);
                if (username != null) {
                    try {
                    	// *** CAUTION ***
                    	// This is designed to associate the transient user with a provisioned user, if one exists.
                    	// However, for any environment using both OIDC and a traditional user registry,
                    	// this could be a security vulnerability if the username exists in both the OP and the DX registry.
                    	//
                        // try to find valid user for given username/eMail
                        InitialContext ctx = new InitialContext();
                        UserRegistry reg = (UserRegistry) ctx.lookup("UserRegistry");
                        uniqueid = reg.getUniqueUserId(username);
                    } catch (com.ibm.websphere.security.EntryNotFoundException e1) {
                        // Entry was not found - or not unique in defaultRealm
                    	// This is not designed for VP / Realms.
                    	// This does not extend group membership.
                        System.out.println("HCLDummyJAAS - transient user");
                        
                        // Full reliance on callbacks for WSCREDENTIAL_UNIQUEID is not generally considered secure, thus the disclaimer.
                        // Valid OIDC TAI and WEB_INBOUND configuration should be sufficient to ensure the security of this code.
                        // Third-party security analysis is recommended for any custom login module. 
                        uniqueid = "uid=" + username + ",o=transparent";
                        hashtable.put(AttributeNameConstants.WSCREDENTIAL_UNIQUEID,uniqueid);
                        hashtable.put(AttributeNameConstants.WSCREDENTIAL_SECURITYNAME,uniqueid);
                        
                        // Add attributes for this user.
                        // Native WAS security code could access these from the public credentials.
                        // See ExternalIdentityCredential comments, below.
                        hashtable.put("sn",username);
                        hashtable.put("cn",username);
                        hashtable.put("uid",username);
                        hashtable.put("ibm-primaryEmail",username+"@hcl.com");
                        currentSubject.getPublicCredentials().add(hashtable);
                        
                        // For explorers -
                        System.out.println("HCLDummyJAAS - OidcClientHelper.getUserInfoFromSubject(currentSubject): " + OidcClientHelper.getUserInfoFromSubject(currentSubject));
                        System.out.println("HCLDummyJAAS - OidcClientHelper.getUserInfoFromServer(currentSubject): " + OidcClientHelper.getUserInfoFromServer(currentSubject));
                        System.out.println("HCLDummyJAAS - OidcClientHelper.getIdTokenFromSubject(currentSubject): " + OidcClientHelper.getIdTokenFromSubject(currentSubject));
                        System.out.println("HCLDummyJAAS - OidcClientHelper.getAccessTokenFromSubject(currentSubject): " + OidcClientHelper.getAccessTokenFromSubject(currentSubject));
                        
                        currentSubject.getPublicCredentials().add(new ExternalIdentityCredential(hashtable));
                        
                        currentSharedState.put(AttributeNameConstants.WSCREDENTIAL_PROPERTIES_KEY,hashtable);
                    } catch (Exception e1) {
                        System.out.println("HCLDummyJAAS failed for user lookup: "+ e1);
                    }
                    System.out.println("uniqueid = " + uniqueid);
                } else {
                	
                    System.out.println("uniqueid is null - do nothing");
                    success = false;
                    System.out.println("HCLDummyJAAS failed with uniqueid= " + uniqueid);
                    return success;
                }
            } else {
                System.out.println("This is a repeat login, nothing to do.");
            }

        } catch (Exception e) {
            System.out.println("HCLDummyJAAS failed: " + e);
        }
        success = true;
        System.out.println("HCLDummyJAAS succeeded with uniqueid = " + uniqueid);
        return success;
    }

    @Override
    public boolean commit() throws LoginException {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean abort() throws LoginException {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean logout() throws LoginException {
        // TODO Auto-generated method stub
        return false;
    }

}
