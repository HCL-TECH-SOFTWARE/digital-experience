<%@page import="java.util.Calendar"%>
<%@page import="java.util.Date"%>
<%@page import="com.ibm.workplace.wcm.api.*"%>
<%@page import="com.ibm.workplace.wcm.api.query.*"%>

Before.
<br>
<%


		Workspace myWorkspace = WCM_API.getRepository().getSystemWorkspace();

	    myWorkspace.login();

	    try{
	    	DocumentLibrary lib = myWorkspace.getDocumentLibrary("Web Content");
	    	
	    	myWorkspace.setCurrentDocumentLibrary(lib);
			Query myQuery = myWorkspace.getQueryService().createQuery();
			 

			Calendar cal = Calendar.getInstance();
			
			//older than 2 weeks
            cal.add(Calendar.DATE, -14);
            Date myDate = cal.getTime();
            
            DocumentIdIterator iterator = myWorkspace.findItemsDeletedSince(myDate, null, null);
			
			while (iterator.hasNext()) {
				DocumentId next = (DocumentId) iterator.next();
				%><%= next %><br><%
						
				myWorkspace.purge(next);
			}	
			
		}finally {
			myWorkspace.logout();
		}

%>
<br>
After.
