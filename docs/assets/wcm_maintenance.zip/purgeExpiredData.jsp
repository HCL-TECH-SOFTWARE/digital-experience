<%@page import="java.util.Calendar"%>
<%@page import="java.util.Date"%>
<%@page import="com.ibm.workplace.wcm.api.*"%>
<%@page import="com.ibm.workplace.wcm.api.query.*"%>

Before.
<br>
<%


		Workspace myWorkspace = WCM_API.getRepository().getSystemWorkspace();

	    myWorkspace.login();

	    try{
	    	DocumentLibrary lib = myWorkspace.getDocumentLibrary("Web Content");
	    	
	    	myWorkspace.setCurrentDocumentLibrary(lib);
			Query myQuery = myWorkspace.getQueryService().createQuery();
			
			myQuery.addSelector(Selectors.libraryEquals(lib));
		
			myQuery.addSelector(WorkflowSelectors.statusIn(WorkflowSelectors.Status.EXPIRED));
			
			//older than 2 weeks
			Calendar cal = Calendar.getInstance();

            cal.add(Calendar.DATE, -14);
            Date myDate = cal.getTime();

		    myQuery.addSelector(HistorySelectors.modifiedBefore(myDate));

			ResultIterator<Document> iterator = myWorkspace.getQueryService().execute(myQuery);
			
			while (iterator.hasNext()) {
				Document next = iterator.next();
				%><%= next %><br><%
						
				myWorkspace.purge(next.getId());
			}	
			
		}finally {
			myWorkspace.logout();
		}

%>
<br>
After.
